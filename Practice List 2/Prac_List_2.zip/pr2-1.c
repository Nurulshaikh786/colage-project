#include<stdio.h>
int main(){
	int i;
	printf("\n\n");
	for(i=1;i<=50;i++){
		printf("%d",i);
	}
}
